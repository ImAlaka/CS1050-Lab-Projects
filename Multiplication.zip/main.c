/* Alec Burke
Prelab 2 */
#include <stdio.h>

// Function main begins program execution 
int main (void)
{

  int X; /* First Number to be input by user (this just assigns the integer 1 to X) */
  int Y; /* Second number to be input by user */
  int product; // variable in which product will be stored //
  int quotient; // variable in which the qotuient will be stored 
  int equation; // variable in which the (X+1 * Y) will be stored

	printf ( "Enter First Integer\n" ); /* Prompt 1 */
	scanf ( "%d", &X ); /* Reads an Integer */
	
	printf ( "Enter Second integer\n" ); /*Prompt 2 */
	scanf ( "%d", &Y ); /* Reads an integer */
	
  product = X * Y; // assign total to the product
  quotient = X / Y; // assign total to the quotient
  equation = (1+X) * Y; // assign total to the quotient

  printf( "product is %d\n", product); // prints product
  printf( "quotient is %d\n", quotient); // prints quotient
  printf( "equation is %d\n",equation); // prints quotient
  printf( "X is %d\n", X); // prints value of X
  printf( "Y is %d\n", Y); // prints value of Y

	return 0; /* inidicate that program ended succsesfully 
	I.e ends main function */	
}